from iska_python_project.greeters.hello_word import HelloWorld


class HelloWorld:
    def greet(self):
        return "Hello, World!"
