class HelloWorld:
    def greet(self):
        return "Hello, World!"
